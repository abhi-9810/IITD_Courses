import java.util.Scanner;
public class RoutingMapTree extends Thread{ 
          public static Exchange root=new Exchange(0);
         //rejistring mobile
          public  void switchOn(MobilePhone m1, Exchange b){
             Exchange e=b;
             if(e.m==null)
                 e.m=new Myset();
                  e.m.Insert(m1);
                    m1.exchange=e;              
                   Exchange e1=e.parent();
                     while(e1!=null){
                       if(e1.m==null)
                       e1.m=new Myset();
                       e1.m.Insert(m1);
                       e1=e1.parent(); 
                     }
          }
          //switchoff mobile a
          public void switchOff(MobilePhone a){
              a.switchOff();
              Exchange e=a.location();
              while(e!=null){
                     if(e.m.mobile.number==a.number)
                       e.m=e.m.link;
                     else
                     e.m.Delete(a);
                     e=e.parent();  
                 }
              }   
           
         //give  the exchange to which it is connected
          public Exchange findPhone(int m){
            int number=m;
                 Myset m3=root.m;
                try{ 
                while(m3!=null){
                   if(m3.mobile.number==number)
                        break;
                    m3=m3.link;
                 }
                  MobilePhone m1=m3.mobile;
                  Exchange e=m3.mobile.exchange;
                  return e;
                  }catch(Exception e)
                    {System.out.println(": No mobile phone found");
                      return null;
                  }
           }
            
         public boolean tocall(MobilePhone a,MobilePhone b,int time){
            if(b.busy){
              //System.out.println("Waiting: Person is busy");
              return false; 
             }
             else{
             long c1=System.currentTimeMillis();
               a.busy=true;
               b.busy=true;
             long c2=System.currentTimeMillis();
             while(c2-c1<time*1000){
                 c2=System.currentTimeMillis();
             }
              a.busy=false;
              b.busy=false;
             return true;
            }
         }
           
                       
            //return the callpath
          public ExchangeList routeCall(MobilePhone a, MobilePhone b){
               ExchangeList e=new ExchangeList();
               ExchangeList f=new ExchangeList();
               Exchange m=a.exchange;
               //System.out.println(m.identifier);
               e.m=m;
               //f=e.link;
               ExchangeList me=e;
               
               while(m!=root){
                 m=m.parent;
                 ExchangeList s=new ExchangeList();
                 s.m=m;
                 e.link=s;
                 e=e.link;
               }
               //System.out.println(me.link.m.identifier);
               //e.link=me;
               ExchangeList r5=new ExchangeList();
               m=b.exchange;
               r5.m=m;
               ExchangeList mine=r5;
               while(m.parent!=root){
                 m=m.parent();
                 ExchangeList s=new ExchangeList();
                 s.m=m;
                 r5.link=s;
                 r5=r5.link;
               }
               
              //reversing linked list
              e.link=reverse(mine);
              return me;   
          }
             //function to reverse Linkedlist:
            public ExchangeList reverse(ExchangeList r){
              ExchangeList m=r;
              ExchangeList f=null;
              ExchangeList next=null;
              ExchangeList prev=null;
              while(m!=null){
                 next=m.link;
                 m.link=f;
                 f=m;
                  m=next;
              }
               return f;
           }
            // changing the location of the phone
            public void movephone(MobilePhone a ,Exchange b){
              int number=a.number;
              try{
              Myset m=root.m;
                 while(m!=null){
                   if(m.mobile.number==number)
                        break;
                    m=m.link;
                 }a=m.mobile;
                  Exchange e=m.mobile.exchange;
                   switchOff(a);
                     switchOn(a,b);
                     a.status=true;
 
              }catch(Exception e){System.out.println("No mobile Phone Found");}
           } 

             //running central server
             public void run(){
              System.out.println("Give The Number For Which You Want To See The Simulation");
              Scanner s=new Scanner(System.in);
              int number=s.nextInt();
                 Myset m=root.m;
                 while(m!=null){
                   if(m.mobile.number==number){
                     MobilePhone m1=m.mobile;
                     m1.show=1;
                     m1.start();              
                    }
                   else
                    m.mobile.start();       
                    m=m.link;
                   }
               
             }
            //taking argument
	 public void performAction(String actionMessage) {
		System.out.print(actionMessage);
               String s[]=new String[5];
               for(int i=0;i<5;i++)
                  s[i]="";
                 int j=0;
               for(int i=0;i<actionMessage.length();i++){
                  if(actionMessage.charAt(i)!=' ')
                    s[j]=s[j]+actionMessage.charAt(i);
                  else
                    j++;
                  }
           if(s[0].equals("addExchange")){
               Exchange e =give(Integer.parseInt(s[1]));
               Exchange f=new Exchange(Integer.parseInt(s[2]));
                f.parent=e;
                 
                 if(e==null)
                   System.out.println("No exchange found");
                 else{
                      if(e.child==null){
                         e.child=f;
                         f.level=e.level+1; 
                        }
                      else{
                         try{
                            Exchange e1=e.child;                  
                            while(e1.siblings!=null)
                              e1=e1.siblings;
                            e1.siblings=f;
                            f.level=e.level+1;
                         }catch(Exception e2)
                            {System.out.println("No exchange found");}    
                      }                       
                  }
                 System.out.println(" "); 
               }         
               //switch on mobile and connect to a exchange 
           if(s[0].equals("switchOnMobile")){
               MobilePhone m1=new MobilePhone( Integer.parseInt(s[1]));
               m1.switchOn();
               Scanner s99=new Scanner(System.in);
               System.out.println(" ");
               System.out.println("If you want to read input from file for the number " + m1.number+ " type '1'");
               int type=s99.nextInt();
               m1.type=type;
               if(type!=1){
                System.out.println("Give The time(in second) for which u want to run simulation for this number :"+m1.number);
                int time=s99.nextInt();
                m1.time=time;
               } 
               //m1.start();
               Exchange e=give(Integer.parseInt(s[2]));
                 try{
                  if(e.m==null)
                       e.m=new Myset();
                  e.m.Insert(m1);
                    m1.exchange=e;              
                   Exchange e1=e.parent();
                     while(e1!=null){
                       if(e1.m==null)
                       e1.m=new Myset();
                       e1.m.Insert(m1);
                       e1=e1.parent(); 
                     }
                   }
                 catch(Exception e3){
                   e3.printStackTrace();
                    System.out.println("Error-Exchange Doesn't exists");  
                 }
                 System.out.println(" ");
           }
         }  
           
         //find the Exchange with a given identifier 
         public Exchange give(int identifier){
            Exchange p=root; 
            if(identifier==0)
              return root;
            Exchange p1=p.child;
            while(p1!=null){ 
                if(p1.identifier==identifier)
                    return p1;     
                if(contains(p1.siblings,identifier)){
                   if(p1.siblings.identifier==identifier)
                     return p1.siblings;
                   else{
                    if(contains(p1.siblings.siblings,identifier))
                        p1=p1.siblings.siblings;
                      else
                       p1=p1.siblings.child;
                   }
                }
                if(contains(p1.child,identifier)){
                   if(p1.child.identifier==identifier)
                     return p1.child;
                   else{
                    if(contains(p1.child.siblings,identifier))
                        p1=p1.child.siblings;
                      else
                       p1=p1.child.child;
                   }
                  }
               }
               return null;
         } 
        //contains
         public boolean contains(Exchange root1,int id){
           if(root1==null)
             return false;
              if(root1.identifier==id)
                  return true;
               else
                  return (contains(root1.siblings,id)||contains(root1.child,id)) ;
            }

          } 









