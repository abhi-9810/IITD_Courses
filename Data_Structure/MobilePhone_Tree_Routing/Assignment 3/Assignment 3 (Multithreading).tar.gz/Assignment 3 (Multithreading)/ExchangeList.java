public class ExchangeList{
   public Exchange m;
   public ExchangeList link;
}
