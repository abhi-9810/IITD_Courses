import java.util.Random;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java . io .*;
import java.lang.Object;
public class MobilePhone extends Thread{
  public int number;
  public boolean status;
  public boolean busy;
  public Exchange exchange;
  public int type;
  public int time;
  public int show;
  public MobilePhone(int number1){
    number=number1;
  }
  //thread is running here
  public void run(){
   try{Thread.sleep(100);}catch(Exception e){System.out.println("Kya hai yaar");};
   long t1=System.currentTimeMillis();     
   int type=this.type;
   //read from file
   if(type==1){
     MobilePhone m1=new MobilePhone(5);
     BufferedReader br = null;
		try {
			String actionString;
			br = new BufferedReader(new FileReader("input.txt "));
			while ((actionString = br.readLine()) != null) {
			     m1.mobiletask(actionString,this);
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (br != null)br.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
   }
  else{
    int time=this.time;
    long t3=0;
    int show=this.show;
   while(t3<1000*time){
    Random rand = new Random(); 
    int value = rand.nextInt(10000);
    value=value%4;
   //making the input file
    if(show==1){
    /*
    try{
       long t11=System.currentTimeMillis();
         t11=t11-t1;
         FileOutputStream fs = new FileOutputStream ( "input.txt " , true );
           PrintStream p = new PrintStream (fs);
           if(value==0)     
            p.print(t11+" MovePhone "+"-1");
           if(value==1)
            p.print(t11+" Switch "+"-1");
           if(value==2){
            Random random15 = new Random(); 
            int value15 = random15.nextInt(3)+3;
            p.print(t11+" CallSomeone "+value15);
           }
           if(value==3)
            p.print(t11+" OtherWork "+"-1");
                p.println("");            
         }catch ( FileNotFoundException e1 ) {
            System.out.println ( "File not found");
        }
       */
      
}
    if(value==0){
       Random random11 = new Random(); 
       int value111 = random11.nextInt(10);
       int prev=this.exchange.identifier;
       RoutingMapTree r=new RoutingMapTree();
       Exchange b=r.give(value111);
        r.movephone(this,b);
       if(show==1)
        System.out.println("Move phone from "+prev+" base exchange to "+b.identifier);
    }
    if(value==1){
      if(this.status){        
           this.status=false;
          if(this.show==1)
            System.out.println("SwitchingOff the phone");
          }
         else{
          this.status=true;
          if(this.show==1)
            System.out.println("SwitchingOn the phone");
        }
     }
     if(value==2){
       if(!this.status){
         if(this.show==1)
         System.out.println("Can't call Battery Low");
         continue;
       }   
       Random random1 = new Random(); 
       int value11 = random1.nextInt(3)+3;
       RoutingMapTree r1=new RoutingMapTree();
       int n=random1.nextInt(9);
       Myset m=r1.root.m;
       while(n>0){
         m=m.link;
         n--;
       }
       MobilePhone b=m.mobile;
       if(!b.status){
         System.out.println("The number("+b.number+") you are trying to reach is currently SwitchOff please try after sometime");
         continue;
       }
        boolean call= r1.tocall(this,b,value11);  
       if(show==1){
        System.out.println("Call a person randomly for "+value11+".000 seconds");
         if(call)
          System.out.println("Call is sucessful to "+b.number);
         else
          System.out.println(b.number+" is busy");  
        }
       //try{Thread.sleep(value11*1000);}catch(Exception e){System.out.println("Kya hai yaar");}; 
    }
     
      long t2= System.currentTimeMillis(); 
      t3=t2-t1;
      if(value==3){
        Random random = new Random(); 
        int value1 = random.nextInt(10)+1;
        if(show==1)
          System.out.println("Person is busy in another work for "+value1+" Second"); 
        try{Thread.sleep(value1*1000);}catch(Exception e){System.out.println("Kya hai yaar");};   
    }
   }
 }
}


   public void mobiletask(String actionMessage,MobilePhone m1){
     long t15=System.currentTimeMillis();
     String s[]=new String[3];
     s[0]="";s[1]="";s[2]="";
      int j=0;
      for(int i=0;i<actionMessage.length();i++){
         if(actionMessage.charAt(i)!=' ')
           s[j]=s[j]+actionMessage.charAt(i);
         else
           j++;
      }
      long t9=Long.parseLong(s[0]);
      //long t123=System.currentTimeMillis();
      //while(t15-t123>t9){
        //t15=System.currentTimeMillis();
     // }
     if(s[1].equals("Switch")){
         if(m1.status){        
           m1.status=false;
          if(m1.show==1)
            System.out.println("SwitchingOff the phone");
          }
         else{
          m1.status=true;
          if(m1.show==1)
            System.out.println("SwitchingOn the phone");
        }
     }
     if(s[1].equals("MovePhone")){
        Random random11 = new Random(); 
        int value111 = random11.nextInt(10);
        int prev=m1.exchange.identifier;
        RoutingMapTree r=new RoutingMapTree();
        Exchange b=r.give(value111);
        r.movephone(m1,b);
       if(m1.show==1)
        System.out.println("Move phone from "+prev+" base exchange to "+b.identifier);
       }
     
     if(s[1].equals("CallSomeone")){
       if(!m1.status){
         if(m1.show==1)
           System.out.println("Can't call Battery Low");
          return;
       }  
       Random random1 = new Random(); 
       int value11 = Integer.parseInt(s[2]);
       RoutingMapTree r1=new RoutingMapTree();
       int n=random1.nextInt(9);
       Myset m=r1.root.m;
       while(n>0){
         m=m.link;
         n--;
       }
       MobilePhone b=m.mobile;
        if(!b.status){
         System.out.println("The number("+b.number+") you are trying to reach is currently SwitchOff please try after sometime");
         return;
       }
        boolean call= r1.tocall(m1,b,value11);  
       if(m1.show==1){
        System.out.println("Call a person randomly for "+value11+".000 seconds");
         if(call)
          System.out.println("Call is sucessful to "+b.number);
         else
          System.out.println(b.number+" is busy");    
     }
    }
     if(s[1].equals("OtherWork")){
       Random random = new Random(); 
        int value1 = random.nextInt(10)+1;
        if(m1.show==1)
          System.out.println("Person is busy in another work for "+value1+" Second"); 
        try{Thread.sleep(value1*1000);}catch(Exception e){System.out.println("Kya hai yaar");};   
     }
    }
   
   public int number(){
     return number; 
   }
   public void switchOn(){
      status=true;
   }
   public void switchOff(){
      status=false;
   }
  public boolean status(){
     return status;  
  }
  public void makecall(){
      this.busy=true;
  }
   public Exchange location(){
      if(this.exchange!=null)
         return exchange;
      else
        System.out.println("Error - Mobile phone is currently switched off");
       return null;
   }
}
