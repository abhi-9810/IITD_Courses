import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;
import java.util.LinkedList;
import java.util.Comparator;

public class Graph{
   public LinkedList<Node> g=new LinkedList<Node>(); 
   //Shortest Path
   //Dijkstra Algorithm
  public void Dijkstra(Node v){
      LinkedList<Node> temp=this.g;
     for(int i=0;i<temp.size();i++){
        if(temp.get(i)!=v){
          temp.get(i).dist=Integer.MAX_VALUE;
          temp.get(i).marked=false;
         }
        else{
          temp.get(i).dist=0;
          temp.get(i).marked=false;
        }
     }
     int i1=0;
     while(temp.size()!=i1){
       Node u=min(temp);
        u.marked=true;     
    
       for(int i=0;i<u.e.size();i++){
         int alt=0;
         int flag=0; 
         if(u.e.get(i).first!=u)
            alt=u.dist;
         else{
           alt=u.dist;
           flag=1;
         }
          alt+=u.e.get(i).value;
         if(flag==1){
            if(u.e.get(i).second.dist>alt){
              u.e.get(i).second.dist=alt;
              u.e.get(i).second.previous=u;
            }
         }
         else{
           if(u.e.get(i).first.dist>alt){
              u.e.get(i).first.dist=alt; 
              u.e.get(i).first.previous=u;
            }        
         }
     }
       i1++;
     }
       //temp1.print();
  }

    //give path
    public LinkedList<Node> givepath(Node v1,Node v2){
      Graph temp=this;
      //System.out.println(v1.name+"  "+v2.name);
      LinkedList<Node> temp1=new LinkedList<Node>();
      Node temp3=v2;
      while(temp3!=v1){
       temp1.addFirst(temp3);
       temp3=temp3.previous;
      }
      //temp1.addFirst(v1);
     return temp1;
    }
   public int givedist(Node v1,Node v2){
     LinkedList<Edge> temp=v1.e;
     for(int i=0;i<temp.size();i++)
       if(temp.get(i).first==v2||temp.get(i).second==v2)
         return temp.get(i).value;
     return 0;
   }
   //node in q with smallest dist
   public Node min(LinkedList<Node> head1){
     LinkedList<Node>head=new LinkedList<Node>();
     for(int i=0;i<head1.size();i++)
       if(!head1.get(i).marked)
        head.add(head1.get(i));
     Node temp=head.get(0);
     int min=head.get(0).dist;
     for(int i=0;i<head.size();i++)
       if(head.get(i).dist<min){
         min=head.get(i).dist;
         temp=head.get(i); 
       }
      return temp;
   }
  //give node with name
  public Node givenode(String name){
    for(int i=0;i<this.g.size();i++){
      if(this.g.get(i).name.equals(name))
        return this.g.get(i);
    }
    return null;
  }
  public void print(){
    for(int i=0;i<this.g.size();i++){
      System.out.print(this.g.get(i).name+"    Dist. are "+this.g.get(i).dist+" Previous are "+ this.g.get(i).previous.name+"   Edges are");
       for(int i1=0;i1<this.g.get(i).e.size();i1++)
         System.out.print(this.g.get(i).e.get(i1).first.name+" - "+this.g.get(i).e.get(i1).second.name+" & ");
       System.out.println("");
    } 
      
  }
  public void setposition(){
    for(int i=0;i<this.g.size();i++)
        this.g.get(i).pos=i;
  }
}


//Edge Class
class Edge{
  public Node first;
  public Node second;
  public int value;
     
  //construcor
  public Edge(Node f,Node s,int price){
    this.first=f;
    this.second=s;
    this.value=price;
  }

}






