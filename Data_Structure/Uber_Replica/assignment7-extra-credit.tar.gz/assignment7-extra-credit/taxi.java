import java.util.LinkedList;
public class taxi {
  public String cab;
  public Node position;
  public boolean avl;
  public int busy;
  public int time;
  public int index;
  public LinkedList<Node> movingtoward=new LinkedList<Node>();
  //constructor
  public taxi(String cab,Node Position,boolean avl){
    this.cab=cab;
    this.position=Position;
    this.avl=avl;
    this.busy=0;
  }
  //give avaliablity
  public boolean aval(){
    return this.avl;
  }
 //give position
  public Node Position(){
    return this.position;
  }
  public void print(int t1,int t2){
    TaxiService y=new TaxiService();
    while(t1<=t2){//System.out.println(t1+"    "+t2);
     for(int i=0;i<y.taxies.size();i++){
        int index=y.taxies.get(i).index;
         //System.out.println(y.taxies.get(i).cab+"   "+y.taxies.get(i).time+"   "+y.taxies.get(i).avl);
        if(y.taxies.get(i).time==t1&&y.taxies.get(i).avl){
          System.out.print("At time "+t1+", Taxi "+y.taxies.get(i).cab+" chose a new destination vertex from "+y.taxies.get(i).movingtoward.getFirst().name+" to ");
          y.taxies.get(i).position=y.taxies.get(i).movingtoward.getFirst(); 
          y.taxies.get(i).movingtoward.removeFirst();
          if(y.taxies.get(i).movingtoward.size()==0){
            //System.out.println(y.taxies.get(i).position.name+"  "+index);
            y.graph.Dijkstra(y.graph.g.get((index+1)%y.graph.g.size()));
             y.taxies.get(i).movingtoward=y.graph.givepath(y.graph.g.get((index+1)%y.graph.g.size()),y.graph.g.get((index+2)%y.graph.g.size()));        y.taxies.get(i).index=(y.taxies.get(i).index+1)%y.graph.g.size();
          } 
           //for(int i3=0;i3<y.taxies.get(i).movingtoward.size();i3++)
             // System.out.println(y.taxies.get(i).movingtoward.get(i3).name+"        real   estate  "+y.taxies.get(i).movingtoward.get(i3).dist);
           System.out.println(y.taxies.get(i).movingtoward.get(0).name);
          //y.taxies.get(i).time+=y.graph.g.get((index+2)%y.graph.g.size()).dist;
            y.taxies.get(i).time+=y.graph.givedist(y.taxies.get(i).position,y.taxies.get(i).movingtoward.get(0));
           // System.out.println(y.taxies.get(i).time+" ghghfhdfghfghfdhfdhhhhhhhhh");
        }
       if(!y.taxies.get(i).avl && y.taxies.get(i).time==t1){
            y.taxies.get(i).avl=true;
            for(int i1=0;i1<y.graph.g.size();i1++)
              if(y.taxies.get(i).position==y.graph.g.get(i1))
                 y.taxies.get(i).index=i1;
                y.graph.Dijkstra(y.graph.g.get((index)%y.graph.g.size()));
          y.taxies.get(i).movingtoward=y.graph.givepath(y.graph.g.get((index)%y.graph.g.size()),y.graph.g.get((index+1)%y.graph.g.size()));     y.taxies.get(i).time+=y.taxies.get(i).movingtoward.get(0).dist;
        // System.out.println(y.taxies.get(i).position.name+"     "+y.taxies.get(i).movingtoward.get(0).name+"       "+y.taxies.get(i).index);
        }
       if(y.taxies.get(i).busy<t1)
          y.taxies.get(i).avl=true;
      //y.taxies.get(i).time++;
     }
     t1++;
    }
  }
}
