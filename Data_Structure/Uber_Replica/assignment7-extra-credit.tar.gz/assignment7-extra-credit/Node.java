import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;
import java.util.LinkedList;
import java.util.Comparator;
public class Node implements Comparable<Node>{
  public String name="";
  public LinkedList<Edge> e;
  public int dist=0;
  public Node previous;
  public int pos;
  public boolean marked=false;  
  //constructor
  public Node(String s,Edge e1){
    this.name=s;
    e=new LinkedList<Edge>();
    if(e1!=null)
     this.e.add(e1);
     this.previous=this;
  }
  public int compareTo(Node p){
    return this.name.compareTo(p.name);
  }
  public void sort(LinkedList<Node> p){
     Collections.sort(p);
  }
}

