import java.util.LinkedList;

public class TaxiService{
       public LinkedList<String> nodes;
       public static Graph graph=new Graph();
       public static LinkedList<taxi> taxies=new LinkedList<taxi>();
       public int initialtime=0;
       public int flag5=0;
       public TaxiService() {
           nodes=new LinkedList<String>();
	}

	public void performAction(String actionMessage) {
           String s[]=new String[8];
           for(int i=0;i<8;i++)
             s[i]="";
            int j=0;
           for(int i=0;i<actionMessage.length();i++){
             if(actionMessage.charAt(i)!=' ')
               s[j]+=actionMessage.charAt(i);
             else
               j++;   
           }
           //adding edge
           if(s[0].equals("edge")){
            System.out.println("action to be performed: " + actionMessage);
            int flag1=0;
            int flag2=0;
            Node temp;
            Node temp1;
             if(!nodes.contains(s[1])){
                temp=new Node(s[1],null);
               nodes.add(s[1]);
               flag1=1;
             }
             else
               temp=graph.givenode(s[1]);
              if(!nodes.contains(s[2])){
                temp1=new Node(s[2],null);
               nodes.add(s[2]);
               flag2=1;
             }
             else
               temp1=graph.givenode(s[2]);
             Edge e=new Edge(temp,temp1,Integer.parseInt(s[3]));
             if(temp!=null)
              temp.e.add(e);
              temp1.e.add(e);
             if(flag1==1)
              graph.g.add(temp);
             if(flag2==1)
              graph.g.add(temp1); 
           }
          //adding taxi
          if(s[0].equals("taxi")){
             System.out.println("action to be performed: " + actionMessage);
             if(flag5==0){ 
                flag5=1;
               graph.g.get(0).sort(graph.g);
             graph.setposition();  
             }       
             Node v1=graph.givenode(s[2]);
             taxi temp=new taxi(s[1],graph.givenode(s[2]),true);
             for(int i=0;i<graph.g.size();i++)
                if(v1==graph.g.get(i))
                  temp.index=i;
             graph.Dijkstra(graph.g.get((temp.index)%graph.g.size()));
             temp.movingtoward=graph.givepath(graph.g.get((temp.index)%graph.g.size()),graph.g.get((temp.index+1)%graph.g.size()));
             temp.time=temp.movingtoward.get(0).dist;   
             //System.out.println(temp.time+"egeeeeeeeee");        
               taxies.add(temp);
          }
          //giving position of taxi
          if(s[0].equals("printTaxiPosition")){
            taxies.get(0).print(initialtime,Integer.parseInt(s[1]));
                System.out.println("action to be performed: " + actionMessage);
                initialtime=Integer.parseInt(s[1]);
            for(int i=0;i<taxies.size();i++)
              if(Integer.parseInt(s[1])>=taxies.get(i).busy)
                System.out.println("taxi "+taxies.get(i).cab+": "+taxies.get(i).position.name);      
          }
         //giving path to the customer
          if(s[0].equals("customer")){
              //System.out.println(initialtime+"   "+Integer.parseInt(s[7]));
              taxies.get(0).print(initialtime,Integer.parseInt(s[7]));
               System.out.println("action to be performed: " + actionMessage); 
               initialtime=Integer.parseInt(s[7]); 
           try{
             Node v11=graph.givenode(s[1]);
             
             //graph.Dijkstra(v1);
             //graph.print();
             System.out.println("Available taxis:");
             int min=Integer.MAX_VALUE;
             int index=0;
             int flag=0;
             for(int i=0;i<taxies.size();i++){
               if(taxies.get(i).busy<=Integer.parseInt(s[7])){
                  Node v1=v11;
                  System.out.print("Path of taxi "+taxies.get(i).cab+": ");
                  flag=1;
                  int reach1=Integer.parseInt(s[3]);
                  graph.Dijkstra(taxies.get(i).position);
                  
                  int time=graph.givedist(taxies.get(i).movingtoward.get(0),taxies.get(i).position)-taxies.get(i).time+Integer.parseInt(s[7]);
                  
                     System.out.println(" ");                    
                   //  System.out.println(time);
                 // System.out.println(taxies.get(i).position.name+"    "+taxies.get(i).movingtoward.get(0).name);
                  int min1=time+v1.dist+reach1;
                  int min2=time+graph.givenode(s[2]).dist+graph.givedist(graph.givenode(s[2]),v1)-reach1;
                  graph.Dijkstra(taxies.get(i).movingtoward.get(0));
                  int min3=taxies.get(i).time-time+v1.dist+reach1;
                  int min4=taxies.get(i).time-time+graph.givenode(s[2]).dist+graph.givedist(graph.givenode(s[2]),v1)-reach1;
                  System.out.println(min1+" "+min2+" "+min3+" "+min4);
                  LinkedList<Node> temp=new LinkedList<Node>();
                   if(min1<=min2&&min1<=min3&&min1<=min4){
                      graph.Dijkstra(taxies.get(i).position);                                                         
                     temp= graph.givepath(taxies.get(i).position,v1);
                     time=min1;
                     System.out.print(taxies.get(i).position.name+", ");
                   }
                   if(min2<=min1&&min2<=min3&&min2<=min4){
                      graph.Dijkstra(taxies.get(i).position);                                                         
                      temp=graph.givepath(taxies.get(i).position,graph.givenode(s[2]));
                       v1=graph.givenode(s[2]);
                       time=min2;
                      System.out.print(taxies.get(i).position.name+", ");
                   }
                     if(min3<=min1&&min3<=min2&&min3<=min4){
                      graph.Dijkstra(taxies.get(i).movingtoward.get(0));                                                         
                      temp=graph.givepath(taxies.get(i).movingtoward.get(0),v1);
                      time=min3;
                      System.out.print(taxies.get(i).movingtoward.get(0).name+", ");
                   }
                     if(min4<=min1&&min4<=min2&&min4<=min3){
                      graph.Dijkstra(taxies.get(i).movingtoward.get(0));                                                         
                      temp=graph.givepath(taxies.get(i).movingtoward.get(0),graph.givenode(s[2]));
                      v1=graph.givenode(s[2]);
                      time=min4;
                      System.out.print(taxies.get(i).movingtoward.get(0).name+", ");
                   }
                  
                  for(int i1=0;i1<temp.size();i1++)
                    System.out.print(temp.get(i1).name+", ");
                    
                  System.out.println(":: time taken is "+time+" units");
                  if(time<min){
                    min=time;
                    index=i; 
                  } 
               }
             }
           if(flag==1){
            System.out.println("** Chose taxi "+taxies.get(index).cab+" to service the customer request ***");  
            LinkedList<Node> temp1=new LinkedList<Node>();
            graph.Dijkstra(taxies.get(index).position);
            taxies.get(index).time=taxies.get(index).time-taxies.get(index).movingtoward.get(0).dist+min+Integer.parseInt(s[7]);
            graph.Dijkstra(v11);
            int min1=graph.givenode(s[4]).dist+Integer.parseInt(s[6]);
            int min2=graph.givenode(s[5]).dist+graph.givedist(graph.givenode(s[5]),graph.givenode(s[4]))-Integer.parseInt(s[6]);             
             Node v2;    
             int min5;
             if(min1>min2){
              v2=graph.givenode(s[5]);
              min5=min2; 
            }
             else{
              v2=graph.givenode(s[4]);
              min5=min1;
             }
            temp1=graph.givepath(v11,v2);
            System.out.print("Path of customer: ");
            System.out.print(s[1]+" "+s[2]+" "+s[3]+", ");  
            for(int i=0;i<temp1.size();i++)
              System.out.print(temp1.get(i).name+", ");
             System.out.print(s[4]+" "+s[5]+" "+s[6]+" ");
             System.out.println(":: time taken is "+min5+" units");
             taxies.get(index).busy+=min5;
             taxies.get(index).position=v2;
             taxies.get(index).avl=false;
             taxies.get(index).time=Integer.parseInt(s[7])+min5;
               //System.out.println(taxies.get(index).time+"this is ......");
          }
          else
            System.out.println("No Taxies Available");
        }
       catch(Exception e){
          System.out.println("Position not found");
        }
     }
   }
}
